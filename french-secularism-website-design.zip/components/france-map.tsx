"use client"

import { useState } from "react"

type Site = {
  id: string
  name: string
  label: string
  detail: string
  x: number
  y: number
}

const sites: Site[] = [
  {
    id: "reims",
    name: "Reims",
    label: "Coronation of Kings",
    detail: "For centuries French kings were anointed at Reims Cathedral, sealing the sacred bond between crown and Church.",
    x: 58,
    y: 26,
  },
  {
    id: "paris",
    name: "Paris",
    label: "Notre-Dame & the Republic",
    detail: "From the Gothic glory of Notre-Dame to the debates of the National Assembly, Paris shaped France's spiritual and secular destiny.",
    x: 50,
    y: 30,
  },
  {
    id: "tours",
    name: "Tours",
    label: "Cradle of Christian Gaul",
    detail: "St Martin of Tours became a pillar of early French Christianity, drawing pilgrims for over a thousand years.",
    x: 42,
    y: 44,
  },
  {
    id: "nantes",
    name: "Nantes",
    label: "Edict of Nantes, 1598",
    detail: "Henry IV granted Protestants toleration here, ending the Wars of Religion for nearly a century.",
    x: 27,
    y: 46,
  },
  {
    id: "lyon",
    name: "Lyon",
    label: "Ancient Christian Centre",
    detail: "One of the earliest Christian communities in Gaul, home to martyrs and a lasting religious legacy.",
    x: 64,
    y: 58,
  },
  {
    id: "avignon",
    name: "Avignon",
    label: "Seat of the Popes",
    detail: "For much of the 14th century the papacy resided in Avignon, making France the center of Western Christendom.",
    x: 62,
    y: 74,
  },
]

// Stylized decorative outline of metropolitan France (l'Hexagone).
const FRANCE_PATH =
  "M300 40 L360 60 L420 55 L470 95 L455 150 L500 185 L560 215 L545 275 L500 300 L515 360 L470 420 L500 470 L455 520 L400 545 L380 590 L320 560 L270 575 L235 540 L180 560 L150 510 L95 495 L110 435 L70 400 L100 350 L60 300 L95 240 L80 180 L140 150 L175 100 L235 105 L270 65 Z"

export function FranceMap() {
  const [active, setActive] = useState<Site>(sites[0])

  return (
    <div className="mx-auto grid max-w-5xl items-center gap-8 px-6 md:grid-cols-[1.1fr_1fr]">
      <div className="relative">
        <svg
          viewBox="0 0 620 620"
          className="h-auto w-full"
          role="img"
          aria-label="Interactive map of France with key sites in religious history"
        >
          <path
            d={FRANCE_PATH}
            fill="var(--color-secondary)"
            stroke="var(--color-forest)"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
          {sites.map((s) => {
            const isActive = s.id === active.id
            return (
              <g
                key={s.id}
                transform={`translate(${(s.x / 100) * 620} ${(s.y / 100) * 620})`}
                className="cursor-pointer"
                onMouseEnter={() => setActive(s)}
                onFocus={() => setActive(s)}
                onClick={() => setActive(s)}
                tabIndex={0}
                role="button"
                aria-label={`${s.name}: ${s.label}`}
              >
                {isActive && (
                  <circle r="18" fill="var(--color-natgeo)" opacity="0.28">
                    <animate attributeName="r" values="12;22;12" dur="2.4s" repeatCount="indefinite" />
                  </circle>
                )}
                <circle
                  r={isActive ? 8 : 6}
                  fill={isActive ? "var(--color-natgeo)" : "var(--color-gold)"}
                  stroke="var(--color-background)"
                  strokeWidth="2"
                />
                <text
                  x="12"
                  y="5"
                  className="font-sans"
                  fontSize="15"
                  fontWeight={isActive ? 700 : 500}
                  fill="var(--color-charcoal)"
                >
                  {s.name}
                </text>
              </g>
            )
          })}
        </svg>
      </div>

      <div
        className="rounded-2xl border bg-card p-7 shadow-sm"
        style={{ borderColor: "var(--color-border)" }}
      >
        <p className="text-xs font-semibold uppercase tracking-[0.24em]" style={{ color: "var(--color-gold)" }}>
          {active.name}
        </p>
        <h3 className="mt-2 font-serif text-2xl font-semibold" style={{ color: "var(--color-forest)" }}>
          {active.label}
        </h3>
        <p className="mt-4 leading-relaxed" style={{ color: "var(--color-charcoal)" }}>
          {active.detail}
        </p>
        <div className="mt-6 flex flex-wrap gap-2">
          {sites.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => setActive(s)}
              className="rounded-full border px-3 py-1 text-xs font-medium transition-colors"
              style={{
                borderColor: s.id === active.id ? "var(--color-forest)" : "var(--color-border)",
                backgroundColor: s.id === active.id ? "var(--color-forest)" : "transparent",
                color: s.id === active.id ? "var(--color-ivory)" : "var(--color-charcoal)",
              }}
            >
              {s.name}
            </button>
          ))}
        </div>
        <p className="mt-5 text-xs italic" style={{ color: "var(--color-muted-foreground)" }}>
          Hover or tap a marker to explore. Map is a stylized illustration.
        </p>
      </div>
    </div>
  )
}

import { Reveal } from "@/components/reveal"

type PullQuoteProps = {
  quote: string
  cite?: string
}

export function PullQuote({ quote, cite }: PullQuoteProps) {
  return (
    <Reveal as="figure" className="mx-auto my-16 max-w-3xl px-6 text-center">
      <span
        className="mx-auto mb-4 block font-serif text-6xl leading-none"
        style={{ color: "var(--color-natgeo)" }}
        aria-hidden="true"
      >
        &ldquo;
      </span>
      <blockquote className="font-serif text-2xl font-medium italic leading-snug text-balance sm:text-3xl md:text-[2.2rem]" style={{ color: "var(--color-forest)" }}>
        {quote}
      </blockquote>
      {cite && (
        <figcaption
          className="mt-6 text-sm font-semibold uppercase tracking-[0.2em]"
          style={{ color: "var(--color-gold)" }}
        >
          {cite}
        </figcaption>
      )}
    </Reveal>
  )
}

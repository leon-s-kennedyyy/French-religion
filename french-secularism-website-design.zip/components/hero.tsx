"use client"

import { useEffect, useState } from "react"

export function Hero() {
  const [offset, setOffset] = useState(0)

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return
    let frame = 0
    const update = () => setOffset(window.scrollY)
    const onScroll = () => {
      cancelAnimationFrame(frame)
      frame = requestAnimationFrame(update)
    }
    window.addEventListener("scroll", onScroll, { passive: true })
    return () => {
      cancelAnimationFrame(frame)
      window.removeEventListener("scroll", onScroll)
    }
  }, [])

  return (
    <header className="relative h-[100svh] w-full overflow-hidden bg-[--color-charcoal]">
      <div
        className="absolute inset-0 will-change-transform"
        style={{ transform: `translateY(${offset * 0.4}px)` }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/images/hero.png"
          alt="A French Gothic cathedral rising into a dramatic dawn sky"
          className="h-[120%] w-full animate-kenburns object-cover"
        />
      </div>

      {/* Cinematic gradient scrims */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(to bottom, rgba(20,18,14,0.55) 0%, rgba(20,18,14,0.15) 35%, rgba(20,18,14,0.35) 65%, rgba(20,18,14,0.92) 100%)",
        }}
      />

      <div className="relative z-10 mx-auto flex h-full max-w-5xl flex-col items-center justify-center px-6 text-center">
        <p
          className="mb-6 text-xs font-semibold uppercase tracking-[0.42em]"
          style={{ color: "var(--color-natgeo)" }}
        >
          A National Geographic&ndash;Style Feature
        </p>
        <span
          className="mb-8 block h-[3px] w-16"
          style={{ backgroundColor: "var(--color-natgeo)" }}
          aria-hidden="true"
        />
        <h1 className="text-balance font-serif text-5xl font-bold leading-[1.05] text-ivory sm:text-6xl md:text-7xl lg:text-[5.5rem]" style={{ color: "var(--color-ivory)" }}>
          Faith &amp; Republic
        </h1>
        <p
          className="mt-6 max-w-2xl text-pretty text-lg leading-relaxed sm:text-xl"
          style={{ color: "rgba(248,245,238,0.86)" }}
        >
          The long and turbulent story of religion, power, and the birth of secularism in France &mdash;
          from the baptism of a Frankish king to the modern promise of laïcité.
        </p>

        <a
          href="#introduction"
          className="mt-10 inline-flex items-center gap-2 rounded-full border px-6 py-3 text-sm font-semibold uppercase tracking-[0.16em] transition-colors"
          style={{
            borderColor: "rgba(248,245,238,0.4)",
            color: "var(--color-ivory)",
          }}
        >
          Begin the Journey
        </a>
      </div>

      <div
        className="animate-scroll-hint absolute bottom-8 left-1/2 z-10 -translate-x-1/2"
        aria-hidden="true"
      >
        <svg width="26" height="42" viewBox="0 0 26 42" fill="none" stroke="rgba(248,245,238,0.7)">
          <rect x="1" y="1" width="24" height="40" rx="12" strokeWidth="1.5" />
          <circle cx="13" cy="12" r="3" fill="rgba(248,245,238,0.7)" stroke="none" />
        </svg>
      </div>
    </header>
  )
}

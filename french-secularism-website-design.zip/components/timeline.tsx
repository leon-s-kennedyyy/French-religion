import { Reveal } from "@/components/reveal"

type Milestone = {
  year: string
  title: string
  text: string
}

const milestones: Milestone[] = [
  {
    year: "c. 496",
    title: "Baptism of Clovis",
    text: "The Frankish king converts to Catholic Christianity, binding the crown to the Church for over a millennium.",
  },
  {
    year: "800",
    title: "Charlemagne Crowned",
    text: "The pope crowns Charlemagne emperor, fusing sacred and royal authority across the Frankish realm.",
  },
  {
    year: "1200s",
    title: "Age of Cathedrals",
    text: "Chartres, Reims, and Notre-Dame rise as Gothic France becomes the spiritual heart of Europe.",
  },
  {
    year: "1562–1598",
    title: "Wars of Religion",
    text: "Catholics and Huguenots plunge France into decades of civil war, ended by the Edict of Nantes.",
  },
  {
    year: "1789",
    title: "The Revolution",
    text: "Revolutionaries seize Church lands and proclaim the rights of man, challenging religious authority.",
  },
  {
    year: "1801",
    title: "The Concordat",
    text: "Napoleon reconciles the state with Rome, regulating but not abolishing the Church's public role.",
  },
  {
    year: "1905",
    title: "Separation of Church and State",
    text: "The landmark law establishes laïcité — the formal separation of religion and the Republic.",
  },
  {
    year: "Today",
    title: "A Secular Republic",
    text: "France navigates faith, freedom, and neutrality in a diverse, modern, and pluralistic society.",
  },
]

export function Timeline() {
  return (
    <div className="relative mx-auto max-w-3xl px-6">
      {/* Center / left rail */}
      <span
        className="absolute bottom-0 left-[19px] top-2 w-px md:left-1/2 md:-translate-x-1/2"
        style={{ backgroundColor: "var(--color-border)" }}
        aria-hidden="true"
      />
      <ol className="space-y-10 md:space-y-0">
        {milestones.map((m, i) => {
          const left = i % 2 === 0
          return (
            <li
              key={m.year}
              className="relative md:grid md:grid-cols-2 md:items-center md:gap-10"
            >
              <Reveal
                className={`pl-14 md:pl-0 md:py-8 ${
                  left ? "md:col-start-1 md:pr-12 md:text-right" : "md:col-start-2 md:pl-12"
                }`}
              >
                <div
                  className="rounded-xl border bg-card p-5 shadow-sm transition-transform duration-300 hover:-translate-y-1"
                  style={{ borderColor: "var(--color-border)" }}
                >
                  <span
                    className="font-serif text-2xl font-bold"
                    style={{ color: "var(--color-gold)" }}
                  >
                    {m.year}
                  </span>
                  <h3 className="mt-1 font-serif text-xl font-semibold" style={{ color: "var(--color-forest)" }}>
                    {m.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed" style={{ color: "var(--color-charcoal)" }}>
                    {m.text}
                  </p>
                </div>
              </Reveal>

              {/* Node */}
              <span
                className="absolute left-[13px] top-1 h-4 w-4 rounded-full ring-4 md:left-1/2 md:top-1/2 md:-translate-x-1/2 md:-translate-y-1/2"
                style={{
                  backgroundColor: "var(--color-natgeo)",
                  boxShadow: "0 0 0 4px var(--color-background)",
                }}
                aria-hidden="true"
              />
            </li>
          )
        })}
      </ol>
    </div>
  )
}

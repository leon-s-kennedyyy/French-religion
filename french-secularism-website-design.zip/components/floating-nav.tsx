"use client"

import { useEffect, useState } from "react"
import { chapters } from "@/lib/chapters"

export function FloatingNav() {
  const [active, setActive] = useState(chapters[0].id)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const sections = chapters
      .map((c) => document.getElementById(c.id))
      .filter((el): el is HTMLElement => Boolean(el))

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id)
        })
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: 0 },
    )

    sections.forEach((s) => observer.observe(s))
    return () => observer.disconnect()
  }, [])

  const activeIndex = chapters.findIndex((c) => c.id === active)

  return (
    <>
      {/* Desktop vertical chapter rail */}
      <nav
        aria-label="Chapters"
        className="fixed right-6 top-1/2 z-40 hidden -translate-y-1/2 lg:block"
      >
        <ul className="flex flex-col gap-1">
          {chapters.map((c) => {
            const isActive = c.id === active
            return (
              <li key={c.id}>
                <a
                  href={`#${c.id}`}
                  className="group flex items-center justify-end gap-3"
                  aria-current={isActive ? "true" : undefined}
                >
                  <span
                    className={`whitespace-nowrap text-xs uppercase tracking-[0.18em] transition-all duration-300 ${
                      isActive
                        ? "text-[--color-forest] opacity-100"
                        : "text-[--color-charcoal] opacity-0 group-hover:opacity-70"
                    }`}
                    style={{
                      color: isActive ? "var(--color-forest)" : "var(--color-charcoal)",
                    }}
                  >
                    {c.nav}
                  </span>
                  <span
                    className="relative flex h-3 w-3 items-center justify-center"
                    aria-hidden="true"
                  >
                    <span
                      className={`block rounded-full transition-all duration-300 ${
                        isActive ? "h-3 w-3" : "h-1.5 w-1.5 group-hover:h-2.5 group-hover:w-2.5"
                      }`}
                      style={{
                        backgroundColor: isActive ? "var(--color-natgeo)" : "var(--color-gold)",
                        boxShadow: isActive ? "0 0 0 3px rgba(255,209,0,0.25)" : "none",
                      }}
                    />
                  </span>
                </a>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Mobile / tablet compact bar */}
      <div className="fixed inset-x-0 top-1 z-40 flex justify-center px-4 lg:hidden">
        <div
          className="mt-2 flex w-full max-w-md items-center justify-between gap-3 rounded-full border px-4 py-2 backdrop-blur"
          style={{
            backgroundColor: "rgba(248,245,238,0.9)",
            borderColor: "var(--color-border)",
          }}
        >
          <button
            type="button"
            onClick={() => setMenuOpen((v) => !v)}
            className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em]"
            style={{ color: "var(--color-forest)" }}
            aria-expanded={menuOpen}
          >
            <span
              className="grid h-6 w-6 place-items-center rounded-full text-[0.65rem]"
              style={{ backgroundColor: "var(--color-natgeo)", color: "var(--color-charcoal)" }}
            >
              {chapters[activeIndex >= 0 ? activeIndex : 0].number}
            </span>
            {chapters[activeIndex >= 0 ? activeIndex : 0].nav}
          </button>
          <span className="text-[0.7rem] tabular-nums" style={{ color: "var(--color-muted-foreground)" }}>
            {(activeIndex >= 0 ? activeIndex : 0) + 1} / {chapters.length}
          </span>
        </div>

        {menuOpen && (
          <div
            className="absolute left-1/2 top-14 w-[min(92vw,28rem)] -translate-x-1/2 rounded-2xl border p-2 shadow-xl backdrop-blur"
            style={{ backgroundColor: "rgba(248,245,238,0.97)", borderColor: "var(--color-border)" }}
          >
            <ul className="grid grid-cols-2 gap-1">
              {chapters.map((c) => (
                <li key={c.id}>
                  <a
                    href={`#${c.id}`}
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm"
                    style={{
                      color: c.id === active ? "var(--color-forest)" : "var(--color-charcoal)",
                      backgroundColor: c.id === active ? "rgba(255,209,0,0.16)" : "transparent",
                    }}
                  >
                    <span className="font-serif text-xs opacity-60">{c.number}</span>
                    {c.nav}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </>
  )
}

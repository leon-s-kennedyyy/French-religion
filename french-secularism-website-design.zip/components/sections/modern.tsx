import { ChapterHeading } from "@/components/chapter-heading"
import { ParallaxImage } from "@/components/parallax-image"
import { Reveal } from "@/components/reveal"

export function ModernSection() {
  return (
    <section id="modern" className="scroll-mt-24 py-24 md:py-32">
      <ChapterHeading number="VII" kicker="1905 – Today" title="Modern France" />

      <ParallaxImage
        src="/images/modern.png"
        alt="Contemporary photograph of a Paris boulevard in warm golden afternoon light"
        caption="A pluralistic, modern France continues to define what neutrality and freedom mean in daily life."
        className="my-16"
      />

      <Reveal className="mx-auto max-w-2xl px-6">
        <p className="dropcap text-lg leading-[1.85]" style={{ color: "var(--color-charcoal)" }}>
          More than a century on, laïcité remains a cornerstone of the French Republic &mdash; enshrined in
          the very first article of the constitution, which declares France an &ldquo;indivisible, secular,
          democratic and social Republic.&rdquo; Yet it is also a living, contested principle.
        </p>
        <p className="mt-6 text-lg leading-[1.85]" style={{ color: "var(--color-charcoal)" }}>
          In an increasingly diverse society, France continues to debate how neutrality applies to schools,
          public services, and religious symbols in shared spaces. These debates are not signs of failure but
          of a democracy still working out, in each generation, how faith and freedom can coexist.
        </p>
      </Reveal>

      <div className="mx-auto mt-16 grid max-w-4xl gap-6 px-6 sm:grid-cols-2">
        <Reveal className="rounded-2xl border bg-card p-8 shadow-sm">
          <h3 className="font-serif text-xl font-semibold" style={{ color: "var(--color-forest)" }}>
            A Constitutional Value
          </h3>
          <p className="mt-3 leading-relaxed" style={{ color: "var(--color-charcoal)" }}>
            Since 1946 and 1958, secularism has been named in France&apos;s constitution as a defining
            feature of the Republic itself &mdash; not merely a policy, but an identity.
          </p>
        </Reveal>
        <Reveal delay={120} className="rounded-2xl border bg-card p-8 shadow-sm">
          <h3 className="font-serif text-xl font-semibold" style={{ color: "var(--color-forest)" }}>
            A Living Debate
          </h3>
          <p className="mt-3 leading-relaxed" style={{ color: "var(--color-charcoal)" }}>
            From the classroom to the public square, France continually reinterprets laïcité to balance
            individual belief with a shared, neutral public life.
          </p>
        </Reveal>
      </div>
    </section>
  )
}

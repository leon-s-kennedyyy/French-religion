import { ChapterHeading } from "@/components/chapter-heading"
import { ParallaxImage } from "@/components/parallax-image"
import { FranceMap } from "@/components/france-map"
import { Reveal } from "@/components/reveal"

export function MonarchySection() {
  return (
    <section id="monarchy" className="scroll-mt-24 py-24 md:py-32">
      <ChapterHeading number="III" kicker="800 – 1500" title="The Rise of the French Monarchy" />

      <ParallaxImage
        src="/images/monarchy.png"
        alt="Grand medieval French royal coronation inside Reims Cathedral beneath soaring Gothic arches"
        caption="Coronation at Reims — where kings were anointed with holy oil said to descend from heaven itself."
        className="my-16"
      />

      <Reveal className="mx-auto max-w-2xl px-6">
        <p className="dropcap text-lg leading-[1.85]" style={{ color: "var(--color-charcoal)" }}>
          As the Frankish empire gave way to the Kingdom of France, the monarchy wrapped itself in sacred
          authority. Kings were not merely rulers; they were the &ldquo;Most Christian&rdquo; sovereigns,
          anointed at Reims and believed to heal the sick with a touch. The Church crowned them, and in
          return they defended it &mdash; funding crusades, endowing monasteries, and raising the great
          cathedrals that still define the French skyline.
        </p>
        <p className="mt-6 text-lg leading-[1.85]" style={{ color: "var(--color-charcoal)" }}>
          For a time, France even held the papacy itself. From 1309 to 1377, the popes ruled from Avignon,
          making the kingdom the beating heart of Western Christendom. Faith and geography became
          inseparable &mdash; every region bearing its saints, shrines, and sacred rivalries.
        </p>
      </Reveal>

      <div className="mx-auto mt-20 max-w-3xl px-6">
        <Reveal className="mb-10 text-center">
          <h3 className="font-serif text-2xl font-semibold" style={{ color: "var(--color-charcoal)" }}>
            A Sacred Geography
          </h3>
          <p className="mt-2 text-sm uppercase tracking-[0.2em]" style={{ color: "var(--color-gold)" }}>
            Explore the landmarks of religious France
          </p>
        </Reveal>
      </div>
      <FranceMap />
    </section>
  )
}

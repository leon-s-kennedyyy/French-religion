import { ChapterHeading } from "@/components/chapter-heading"
import { ParallaxImage } from "@/components/parallax-image"
import { PullQuote } from "@/components/pull-quote"
import { Reveal } from "@/components/reveal"

const principles = [
  {
    title: "Freedom of Conscience",
    detail: "The Republic guarantees every citizen the liberty to believe, to change belief, or to believe nothing at all.",
  },
  {
    title: "Separation of Powers",
    detail: "The state neither recognizes nor funds any religion, and religious institutions stay out of governance.",
  },
  {
    title: "Equality Before the Law",
    detail: "No faith is privileged; all citizens are treated equally regardless of their religion.",
  },
]

export function LaiciteSection() {
  return (
    <section id="laicite" className="scroll-mt-24 py-24 md:py-32">
      <ChapterHeading number="VI" kicker="The Law of 1905" title="The Birth of Laïcité" />

      <Reveal className="mx-auto mt-12 max-w-2xl px-6">
        <p className="dropcap text-lg leading-[1.85]" style={{ color: "var(--color-charcoal)" }}>
          The nineteenth century swung between restoration and rebellion, but the Third Republic finally
          resolved the ancient question. In 1905, France passed the Law on the Separation of the Churches
          and the State. With a stroke, the Republic ceased to fund or govern any religion &mdash; and
          religion ceased to govern the Republic.
        </p>
      </Reveal>

      <ParallaxImage
        src="/images/laicite.png"
        alt="Early 1900s French Third Republic secular public school classroom in warm sepia tones"
        caption="The secular public school became the great engine of laïcité, shaping citizens rather than believers."
        className="my-16"
      />

      <Reveal className="mx-auto max-w-2xl px-6">
        <p className="text-lg leading-[1.85]" style={{ color: "var(--color-charcoal)" }}>
          Laïcité is not hostility to faith. It is a framework of neutrality: the state steps back so that
          belief becomes a matter of private conscience, and the public sphere belongs equally to all. It
          rests on three enduring pillars.
        </p>
      </Reveal>

      <div className="mx-auto mt-14 grid max-w-4xl gap-6 px-6 md:grid-cols-3">
        {principles.map((p, i) => (
          <Reveal
            key={p.title}
            delay={i * 120}
            className="relative overflow-hidden rounded-2xl border bg-card p-7 shadow-sm"
          >
            <span
              className="mb-4 grid h-11 w-11 place-items-center rounded-full font-serif text-lg font-bold"
              style={{ backgroundColor: "var(--color-natgeo)", color: "var(--color-charcoal)" }}
            >
              {i + 1}
            </span>
            <h3 className="font-serif text-xl font-semibold" style={{ color: "var(--color-forest)" }}>
              {p.title}
            </h3>
            <p className="mt-3 text-sm leading-relaxed" style={{ color: "var(--color-charcoal)" }}>
              {p.detail}
            </p>
          </Reveal>
        ))}
      </div>

      <PullQuote
        quote="The Republic neither recognizes, nor pays for, nor subsidizes any religion."
        cite="Article 2, Law of 9 December 1905"
      />
    </section>
  )
}

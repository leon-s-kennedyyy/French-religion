import { ChapterHeading } from "@/components/chapter-heading"
import { ParallaxImage } from "@/components/parallax-image"
import { PullQuote } from "@/components/pull-quote"
import { Reveal } from "@/components/reveal"

const facts = [
  { stat: "8", label: "Successive wars", detail: "Between 1562 and 1598, France endured eight brutal religious conflicts." },
  { stat: "1572", label: "St Bartholomew's Day", detail: "Thousands of Huguenots were massacred in Paris and across the kingdom." },
  { stat: "1598", label: "Edict of Nantes", detail: "Henry IV granted Protestants limited freedom, restoring an uneasy peace." },
]

export function WarsSection() {
  return (
    <section id="wars" className="scroll-mt-24 py-24 md:py-32">
      <ChapterHeading number="IV" kicker="1562 – 1598" title="The Wars of Religion" />

      <Reveal className="mx-auto mt-12 max-w-2xl px-6">
        <p className="dropcap text-lg leading-[1.85]" style={{ color: "var(--color-charcoal)" }}>
          The Reformation shattered the illusion of a single Christian France. As Protestant ideas swept
          across Europe, French Calvinists &mdash; the Huguenots &mdash; grew into a powerful minority. What
          began as theological dispute erupted into decades of civil war, assassination, and massacre.
        </p>
      </Reveal>

      <ParallaxImage
        src="/images/wars-religion.png"
        alt="Dramatic sixteenth-century French Wars of Religion scene at dusk with torchlight and smoke"
        caption="Faith turned to fire: France was torn apart by conflict between Catholics and Huguenots."
        className="my-16"
      />

      <div className="mx-auto grid max-w-4xl gap-6 px-6 sm:grid-cols-3">
        {facts.map((f, i) => (
          <Reveal
            key={f.label}
            delay={i * 120}
            className="rounded-2xl border bg-card p-7 shadow-sm transition-transform duration-300 hover:-translate-y-1"
          >
            <p className="font-serif text-4xl font-bold" style={{ color: "var(--color-gold)" }}>
              {f.stat}
            </p>
            <p className="mt-2 font-serif text-lg font-semibold" style={{ color: "var(--color-forest)" }}>
              {f.label}
            </p>
            <p className="mt-2 text-sm leading-relaxed" style={{ color: "var(--color-charcoal)" }}>
              {f.detail}
            </p>
          </Reveal>
        ))}
      </div>

      <PullQuote
        quote="Paris is well worth a Mass."
        cite="Attributed to Henry IV, on converting to secure the throne and peace"
      />
    </section>
  )
}

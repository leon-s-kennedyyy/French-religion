import { ChapterHeading } from "@/components/chapter-heading"
import { ParallaxImage } from "@/components/parallax-image"
import { PullQuote } from "@/components/pull-quote"
import { Reveal } from "@/components/reveal"
import { CountUp } from "@/components/count-up"

export function RevolutionSection() {
  return (
    <section id="revolution" className="scroll-mt-24 py-24 md:py-32">
      <ChapterHeading number="V" kicker="1789 – 1799" title="The French Revolution" />

      <ParallaxImage
        src="/images/revolution.png"
        alt="Epic French Revolution history painting of revolutionaries advancing with the tricolor flag through smoke"
        caption="Liberté, égalité, fraternité — the Revolution challenged the throne and the altar alike."
        className="my-16"
      />

      <Reveal className="mx-auto max-w-2xl px-6">
        <p className="dropcap text-lg leading-[1.85]" style={{ color: "var(--color-charcoal)" }}>
          In 1789, the old order collapsed. The Revolution did not merely topple a king &mdash; it confronted
          the Church that had crowned him. Vast ecclesiastical lands were nationalized, clergy were required
          to swear loyalty to the state, and for a radical moment, revolutionaries sought to replace religion
          entirely with new &ldquo;cults&rdquo; of Reason and of the Supreme Being.
        </p>
        <p className="mt-6 text-lg leading-[1.85]" style={{ color: "var(--color-charcoal)" }}>
          They even remade time, introducing a new calendar that erased the Christian week. Though much of
          this was later undone, the Revolution planted an idea that could never be uprooted: that
          sovereignty belongs to the people, not to God&apos;s anointed &mdash; and that the state might stand
          apart from the Church altogether.
        </p>
      </Reveal>

      <div className="mx-auto mt-16 max-w-2xl px-6">
        <Reveal className="rounded-2xl border bg-card p-8 text-center shadow-sm">
          <p className="text-sm uppercase tracking-[0.2em]" style={{ color: "var(--color-gold)" }}>
            Year Zero of a New Era
          </p>
          <p className="mt-3 font-serif text-6xl font-bold" style={{ color: "var(--color-forest)" }}>
            <CountUp to={1789} />
          </p>
          <p className="mt-3 leading-relaxed" style={{ color: "var(--color-charcoal)" }}>
            The Declaration of the Rights of Man proclaimed freedom of opinion, &ldquo;even in matters of
            religion&rdquo; &mdash; the first constitutional seed of French secularism.
          </p>
        </Reveal>
      </div>

      <PullQuote
        quote="No one shall be disquieted on account of his opinions, including religious views."
        cite="Declaration of the Rights of Man and of the Citizen, 1789"
      />
    </section>
  )
}

import { ChapterHeading } from "@/components/chapter-heading"
import { Reveal } from "@/components/reveal"
import { Timeline } from "@/components/timeline"
import { CountUp } from "@/components/count-up"

const stats = [
  { value: 1500, suffix: "+", label: "Years of Christian influence" },
  { value: 1905, suffix: "", label: "The year laïcité became law" },
  { value: 5, suffix: "", label: "Republics reshaping faith & state" },
]

export function IntroductionSection() {
  return (
    <section id="introduction" className="scroll-mt-24 py-24 md:py-32">
      <ChapterHeading number="I" kicker="Setting the Scene" title="A Nation Forged Between Altar and State" />

      <Reveal className="mx-auto mt-12 max-w-2xl px-6">
        <p className="dropcap text-lg leading-[1.85]" style={{ color: "var(--color-charcoal)" }}>
          France did not become a secular republic by accident. Its identity was carved, century by
          century, from the tension between two great powers &mdash; the throne and the Church. To walk
          through French history is to trace a long negotiation over who holds authority over the soul of
          a nation, and where the sacred ends and the state begins.
        </p>
        <p className="mt-6 text-lg leading-[1.85]" style={{ color: "var(--color-charcoal)" }}>
          This is the story of that negotiation: from the baptism of a barbarian king who tied his crown
          to Rome, through cathedrals and crusades, wars fought over the Mass, a revolution that dared to
          rewrite time itself, and finally the quiet, radical idea that faith belongs to the individual
          &mdash; not the government. That idea has a name: <em>laïcité</em>.
        </p>
      </Reveal>

      <div className="mx-auto mt-16 grid max-w-4xl gap-6 px-6 sm:grid-cols-3">
        {stats.map((s, i) => (
          <Reveal
            key={s.label}
            delay={i * 120}
            className="rounded-2xl border bg-card p-7 text-center shadow-sm"
          >
            <p className="font-serif text-5xl font-bold" style={{ color: "var(--color-forest)" }}>
              <CountUp to={s.value} />
              {s.suffix}
            </p>
            <p className="mt-3 text-sm leading-snug" style={{ color: "var(--color-muted-foreground)" }}>
              {s.label}
            </p>
          </Reveal>
        ))}
      </div>

      <div className="mx-auto mt-24 max-w-3xl px-6">
        <Reveal className="mb-12 text-center">
          <h3 className="font-serif text-2xl font-semibold" style={{ color: "var(--color-charcoal)" }}>
            The Journey Ahead
          </h3>
          <p className="mt-2 text-sm uppercase tracking-[0.2em]" style={{ color: "var(--color-gold)" }}>
            Fifteen centuries in eight milestones
          </p>
        </Reveal>
      </div>
      <Timeline />
    </section>
  )
}

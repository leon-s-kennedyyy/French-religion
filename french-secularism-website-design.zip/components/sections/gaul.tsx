import { ChapterHeading } from "@/components/chapter-heading"
import { ParallaxImage } from "@/components/parallax-image"
import { PullQuote } from "@/components/pull-quote"
import { Reveal } from "@/components/reveal"

export function GaulSection() {
  return (
    <section id="gaul" className="scroll-mt-24 py-24 md:py-32">
      <ChapterHeading number="II" kicker="c. 300 – 800 AD" title="The Christianization of Gaul" />

      <Reveal className="mx-auto mt-12 max-w-2xl px-6">
        <p className="dropcap text-lg leading-[1.85]" style={{ color: "var(--color-charcoal)" }}>
          Long before there was a France, there was Gaul &mdash; a patchwork of Roman provinces where a new
          faith spread quietly along trade routes and Roman roads. By the fourth century, Christian
          communities flourished in cities like Lyon and Tours, and bishops became the guardians of order
          as Roman power crumbled.
        </p>
      </Reveal>

      <ParallaxImage
        src="/images/gaul.png"
        alt="Painterly historical scene of the baptism of Clovis in a candlelit stone baptistery"
        caption="The baptism of Clovis, c. 496 — a moment that would bind the Frankish crown to the Catholic Church."
        className="my-16"
      />

      <Reveal className="mx-auto max-w-2xl px-6">
        <p className="text-lg leading-[1.85]" style={{ color: "var(--color-charcoal)" }}>
          The turning point came around 496, when the Frankish king Clovis accepted baptism into Catholic
          Christianity. It was a political masterstroke as much as a spiritual one: by aligning with the
          Church of Rome rather than rival Christian sects, Clovis won the loyalty of the Gallo-Roman
          population and the blessing of its bishops. The alliance between the French crown and the
          Catholic Church &mdash; a bond that would endure for thirteen centuries &mdash; was born.
        </p>
      </Reveal>

      <PullQuote
        quote="To be King of the Franks was to be the Church's eldest son — and its sword."
        cite="On the legacy of Clovis"
      />
    </section>
  )
}

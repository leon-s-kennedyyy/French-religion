import { ChapterHeading } from "@/components/chapter-heading"
import { Reveal } from "@/components/reveal"

const takeaways = [
  {
    n: "01",
    title: "Faith Built the Nation",
    text: "For over a thousand years, Catholicism was woven into the crown, the culture, and the very map of France.",
  },
  {
    n: "02",
    title: "Conflict Forced Tolerance",
    text: "The Wars of Religion taught France, at great cost, that a state could not force a single faith upon its people.",
  },
  {
    n: "03",
    title: "Revolution Redefined Authority",
    text: "1789 shifted sovereignty from the divine right of kings to the rights of citizens.",
  },
  {
    n: "04",
    title: "1905 Separated Church and State",
    text: "Laïcité established state neutrality and freedom of conscience as founding principles of the Republic.",
  },
  {
    n: "05",
    title: "Secularism Is Not Anti-Religion",
    text: "Laïcité protects belief and unbelief alike by keeping the public sphere neutral and open to all.",
  },
  {
    n: "06",
    title: "The Story Continues",
    text: "Modern France still negotiates, in each generation, how faith and freedom share the same republic.",
  },
]

export function TakeawaysSection() {
  return (
    <section id="takeaways" className="scroll-mt-24 py-24 md:py-32" style={{ backgroundColor: "var(--color-forest)" }}>
      <div className="mx-auto max-w-3xl px-6 text-center">
        <Reveal>
          <div className="mb-5 flex items-center justify-center gap-4">
            <span className="h-px w-10" style={{ backgroundColor: "var(--color-natgeo)" }} aria-hidden="true" />
            <span
              className="font-serif text-sm font-semibold uppercase tracking-[0.3em]"
              style={{ color: "var(--color-natgeo)" }}
            >
              Chapter VIII
            </span>
            <span className="h-px w-10" style={{ backgroundColor: "var(--color-natgeo)" }} aria-hidden="true" />
          </div>
          <h2 className="text-balance font-serif text-4xl font-bold sm:text-5xl" style={{ color: "var(--color-ivory)" }}>
            Key Takeaways
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-pretty leading-relaxed" style={{ color: "rgba(248,245,238,0.75)" }}>
            Fifteen centuries distilled into the ideas that shaped a secular republic.
          </p>
        </Reveal>
      </div>

      <div className="mx-auto mt-16 grid max-w-5xl gap-5 px-6 md:grid-cols-2 lg:grid-cols-3">
        {takeaways.map((t, i) => (
          <Reveal key={t.n} delay={(i % 3) * 120}>
            <div
              className="h-full rounded-2xl border p-7 transition-transform duration-300 hover:-translate-y-1"
              style={{
                borderColor: "rgba(248,245,238,0.18)",
                backgroundColor: "rgba(248,245,238,0.05)",
              }}
            >
              <p className="font-serif text-3xl font-bold" style={{ color: "var(--color-natgeo)" }}>
                {t.n}
              </p>
              <h3 className="mt-3 font-serif text-xl font-semibold" style={{ color: "var(--color-ivory)" }}>
                {t.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed" style={{ color: "rgba(248,245,238,0.78)" }}>
                {t.text}
              </p>
            </div>
          </Reveal>
        ))}
      </div>

      <div className="mx-auto mt-20 max-w-2xl px-6 text-center">
        <Reveal>
          <p className="font-serif text-2xl italic leading-snug" style={{ color: "var(--color-ivory)" }}>
            &ldquo;The history of France is, in many ways, the history of a nation learning to separate the
            sacred from the state &mdash; and to let both endure.&rdquo;
          </p>
        </Reveal>
      </div>
    </section>
  )
}

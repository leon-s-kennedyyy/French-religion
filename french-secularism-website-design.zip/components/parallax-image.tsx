"use client"

import { useEffect, useRef, useState } from "react"

type ParallaxImageProps = {
  src: string
  alt: string
  caption?: string
  className?: string
  heightClass?: string
}

export function ParallaxImage({
  src,
  alt,
  caption,
  className = "",
  heightClass = "h-[60vh] md:h-[78vh]",
}: ParallaxImageProps) {
  const wrapRef = useRef<HTMLDivElement | null>(null)
  const [shift, setShift] = useState(0)

  useEffect(() => {
    const node = wrapRef.current
    if (!node) return
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return

    let frame = 0
    const update = () => {
      const rect = node.getBoundingClientRect()
      const viewportH = window.innerHeight
      const progress = (rect.top + rect.height) / (viewportH + rect.height)
      setShift((0.5 - progress) * 12)
    }
    const onScroll = () => {
      cancelAnimationFrame(frame)
      frame = requestAnimationFrame(update)
    }
    update()
    window.addEventListener("scroll", onScroll, { passive: true })
    window.addEventListener("resize", onScroll)
    return () => {
      cancelAnimationFrame(frame)
      window.removeEventListener("scroll", onScroll)
      window.removeEventListener("resize", onScroll)
    }
  }, [])

  return (
    <figure className={className}>
      <div ref={wrapRef} className={`relative w-full overflow-hidden ${heightClass}`}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={src || "/placeholder.svg"}
          alt={alt}
          className="absolute inset-0 h-[118%] w-full object-cover"
          style={{ transform: `translateY(${shift}%)` }}
        />
      </div>
      {caption && (
        <figcaption
          className="mx-auto max-w-3xl px-6 pt-3 text-center text-sm italic"
          style={{ color: "var(--color-muted-foreground)" }}
        >
          {caption}
        </figcaption>
      )}
    </figure>
  )
}

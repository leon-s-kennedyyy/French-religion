import { Reveal } from "@/components/reveal"

type ChapterHeadingProps = {
  number: string
  kicker: string
  title: string
}

export function ChapterHeading({ number, kicker, title }: ChapterHeadingProps) {
  return (
    <Reveal className="mx-auto max-w-3xl px-6 text-center">
      <div className="mb-5 flex items-center justify-center gap-4">
        <span className="h-px w-10" style={{ backgroundColor: "var(--color-gold)" }} aria-hidden="true" />
        <span
          className="font-serif text-sm font-semibold uppercase tracking-[0.3em]"
          style={{ color: "var(--color-gold)" }}
        >
          Chapter {number}
        </span>
        <span className="h-px w-10" style={{ backgroundColor: "var(--color-gold)" }} aria-hidden="true" />
      </div>
      <p
        className="mb-3 text-xs font-semibold uppercase tracking-[0.3em]"
        style={{ color: "var(--color-natgeo)" }}
      >
        {kicker}
      </p>
      <h2 className="text-balance font-serif text-4xl font-bold leading-tight sm:text-5xl" style={{ color: "var(--color-charcoal)" }}>
        {title}
      </h2>
    </Reveal>
  )
}

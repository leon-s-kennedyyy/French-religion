export type Chapter = {
  id: string
  number: string
  title: string
  nav: string
}

export const chapters: Chapter[] = [
  { id: "introduction", number: "I", title: "Introduction", nav: "Introduction" },
  { id: "gaul", number: "II", title: "The Christianization of Gaul", nav: "Christianization" },
  { id: "monarchy", number: "III", title: "The Rise of the French Monarchy", nav: "The Monarchy" },
  { id: "wars", number: "IV", title: "The Wars of Religion", nav: "Wars of Religion" },
  { id: "revolution", number: "V", title: "The French Revolution", nav: "Revolution" },
  { id: "laicite", number: "VI", title: "The Birth of Laïcité", nav: "Laïcité" },
  { id: "modern", number: "VII", title: "Modern France", nav: "Modern France" },
  { id: "takeaways", number: "VIII", title: "Key Takeaways", nav: "Takeaways" },
]

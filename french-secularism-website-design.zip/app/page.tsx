import { ReadingProgress } from "@/components/reading-progress"
import { FloatingNav } from "@/components/floating-nav"
import { Hero } from "@/components/hero"
import { IntroductionSection } from "@/components/sections/introduction"
import { GaulSection } from "@/components/sections/gaul"
import { MonarchySection } from "@/components/sections/monarchy"
import { WarsSection } from "@/components/sections/wars"
import { RevolutionSection } from "@/components/sections/revolution"
import { LaiciteSection } from "@/components/sections/laicite"
import { ModernSection } from "@/components/sections/modern"
import { TakeawaysSection } from "@/components/sections/takeaways"

export default function Page() {
  return (
    <>
      <ReadingProgress />
      <FloatingNav />
      <main>
        <Hero />
        <IntroductionSection />
        <SectionDivider />
        <GaulSection />
        <SectionDivider />
        <MonarchySection />
        <SectionDivider />
        <WarsSection />
        <SectionDivider />
        <RevolutionSection />
        <SectionDivider />
        <LaiciteSection />
        <SectionDivider />
        <ModernSection />
        <TakeawaysSection />
      </main>
      <footer className="bg-[--color-charcoal] py-14 text-center" style={{ backgroundColor: "var(--color-charcoal)" }}>
        <div className="mx-auto max-w-2xl px-6">
          <p className="font-serif text-xl font-semibold" style={{ color: "var(--color-ivory)" }}>
            Faith &amp; Republic
          </p>
          <p className="mt-3 text-sm leading-relaxed" style={{ color: "rgba(248,245,238,0.6)" }}>
            An educational feature on the history of religion and secularism in France. Created as a
            National Geographic&ndash;style storytelling experience for learning and reflection.
          </p>
          <p className="mt-6 text-xs uppercase tracking-[0.24em]" style={{ color: "var(--color-natgeo)" }}>
            Liberté &middot; Égalité &middot; Laïcité
          </p>
        </div>
      </footer>
    </>
  )
}

function SectionDivider() {
  return (
    <div className="mx-auto flex max-w-3xl items-center justify-center gap-4 px-6" aria-hidden="true">
      <span className="h-px flex-1" style={{ backgroundColor: "var(--color-border)" }} />
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path
          d="M12 2 L14 10 L22 12 L14 14 L12 22 L10 14 L2 12 L10 10 Z"
          fill="var(--color-gold)"
        />
      </svg>
      <span className="h-px flex-1" style={{ backgroundColor: "var(--color-border)" }} />
    </div>
  )
}
